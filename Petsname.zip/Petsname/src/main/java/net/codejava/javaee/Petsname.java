package net.codejava.javaee;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Petsname
 */
@WebServlet("/petsname")
public class Petsname extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Petsname() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String details = request.getParameter("name");
		String[] array = details.split(",");
		String[] names = new String[array.length/2];
		Double[] marks = new Double[array.length/2];
		int count = 0; 
		for(int i=0;i<array.length; i=i+2) {
			if(i%2==0 || i==0) {
				names[count]= array[i];
				marks[count]=Double.valueOf(array[i+1]);
				count++;
			}
		}
	//sorting
		double tempVar= 0;
		String tempVari = "";
		 int n = marks.length;  
		for (int i = 0; i <n; i++)
		{
		       for(int j = 1; j < (n-i); j++)
		       {
		                if(marks[j-1] < marks[j])
		                {
		                            tempVar = marks [j - 1];
		                            marks [j - 1]= marks [j];
		                            marks [j] = tempVar;
		                            tempVari = names[j-1];
		                            names[j-1] = names[j];
		                            names[j] = tempVari;
		                }
		        }
		}
		
		PrintWriter writer = response.getWriter();
		for (int i = 0; i < marks.length; i++){
			writer.println("<h1> " + names[i] +"  "+marks[i]+ "</h1>");
		}
		writer.close();
		
		
	}

}
